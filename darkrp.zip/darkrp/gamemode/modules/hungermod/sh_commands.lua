DarkRP.declareChatCommand{
    command = "buyfood",
    description = "Buy food.",
    delay = 1.5
}
